function sayHello(){
  var response = prompt('怎么称呼您呢?')
  alert("好的！" + response + ",期待您可以在水果农场里收获满满!");
};

function sayNo(){
  var response = prompt('怎么称呼您呢?')
  alert("好吧！" + response + "，希望你可以玩到其他的东西～");
};
